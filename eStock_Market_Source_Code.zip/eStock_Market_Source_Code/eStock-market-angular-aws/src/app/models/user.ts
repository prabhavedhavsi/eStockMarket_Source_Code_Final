export class User {
    firstName: string;
    lastName: string;
    dob: Date;
    username: string;
    password: string;
    token?: string;
  }