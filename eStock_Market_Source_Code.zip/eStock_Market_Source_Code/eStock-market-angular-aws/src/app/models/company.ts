export class Company {
    companyCode: string;
    companyName: string;
    ceo: string;
    companyTurnover: number;
    companyWebsite: string;
    stockExchangeName: string;
  }